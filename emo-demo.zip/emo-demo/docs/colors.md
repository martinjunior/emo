---
name: colors
category: standards
---

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis et error eius quasi dolorem pariatur temporibus ad fuga minus dolore nemo, inventore sapiente, aliquam repellat, distinctio fugit culpa obcaecati perspiciatis.