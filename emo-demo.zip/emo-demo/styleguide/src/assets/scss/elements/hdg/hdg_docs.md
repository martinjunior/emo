Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa quidem, deleniti, unde et pariatur cupiditate earum commodi at adipisci neque similique ducimus consequuntur iusto tempore impedit praesentium suscipit reiciendis asperiores.

<div class="sg-example">
    <h3 class="hdg">I'm a heading</h3>
</div>

```markup
<h3 class="hdg">I'm a heading</h3>
```

## Size Extensions

### Primary Heading

<div class="sg-example">
    <h3 class="hdg hdg_1">I'm a heading</h3>
</div>

```markup
<h3 class="hdg hdg_1">I'm a heading</h3>
```

### Secondary Heading

<div class="sg-example">
    <h3 class="hdg hdg_2">I'm a heading</h3>
</div>

```markup
<h3 class="hdg hdg_2">I'm a heading</h3>
```

### Tertiary Heading

<div class="sg-example">
    <h3 class="hdg hdg_3">I'm a heading</h3>
</div>

```markup
<h3 class="hdg hdg_3">I'm a heading</h3>
```

### Quaternary Heading

<div class="sg-example">
    <h3 class="hdg hdg_4">I'm a heading</h3>
</div>

```markup
<h3 class="hdg hdg_4">I'm a heading</h3>
```