Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia autem recusandae libero sit repellendus, quis nisi facere quas illo, soluta est quos id quaerat itaque, pariatur voluptatum tempora alias laboriosam.

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ad.

<div class="sg-example">
    <p class="txt">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

## Size Extensions

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis!

### Extra Small

<div class="sg-example">
    <p class="txt txt_xs">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_xs">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

### Large

<div class="sg-example">
    <p class="txt txt_lg">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_lg">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

### Extra Large

<div class="sg-example">
    <p class="txt txt_xl">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_xl">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

## Line-height Extensions

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque dicta, ipsum eaque impedit! Alias unde rem quas non officiis esse.

### Tight

<div class="sg-example">
    <p class="txt txt_tight">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_tight">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

### Loose

<div class="sg-example">
    <p class="txt txt_loose">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_loose">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

## Other Extensions

### Bold

<div class="sg-example">
    <p class="txt txt_thick">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_thick">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```

### Uppercased

<div class="sg-example">
    <p class="txt txt_upper">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
</div>

```markup
<p class="txt txt_upper">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, hic! Error ad, quidem odio officiis, nihil facere dolorem amet nesciunt consequuntur a molestiae ab quo similique doloribus obcaecati! Officiis, veritatis.</p>
```