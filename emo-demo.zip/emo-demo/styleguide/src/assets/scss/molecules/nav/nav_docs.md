Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore enim amet, reprehenderit pariatur ab optio explicabo a numquam suscipit repellendus impedit assumenda quam labore quaerat odit molestiae porro totam blanditiis aspernatur, consequatur hic asperiores iusto dignissimos. Debitis eveniet quia nostrum aperiam qui numquam rerum!

<div class="sg-example">
    <nav class="nav">
        <a href="#" class="nav-item">Home</a>
        <a href="#" class="nav-item">About</a>
        <a href="#" class="nav-item">Contact</a>
    </nav>
</div>

```markup
<nav class="nav">
    <a href="#" class="nav-item">Home</a>
    <a href="#" class="nav-item">About</a>
    <a href="#" class="nav-item">Contact</a>
</nav>
```