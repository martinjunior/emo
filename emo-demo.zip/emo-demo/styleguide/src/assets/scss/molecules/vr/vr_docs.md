Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat deserunt impedit cumque sit nisi repudiandae nesciunt quas natus officiis odit voluptatibus nobis eveniet soluta itaque modi, veniam id sint eaque.

<div class="sg-example">
    <div class="vr">
        <div style="height:50px;background:#333333;"></div>
    </div>
    I have 5px of margin above me!
</div>

```markup
<div class="vr">
    <div style="height:50px;background:#333333;"></div>
</div>
I have 5px of margin above me!
```

## Spacing Extensions

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime, perferendis!

### 10px

<div class="sg-example">
    <div class="vr vr_x2">
        <div style="height:50px;background:#333333;"></div>
    </div>
    I have 5px of margin above me!
</div>

```markup
<div class="vr vr_x2">
    <div style="height:50px;background:#333333;"></div>
</div>
I have 5px of margin above me!
```

### 15px

<div class="sg-example">
    <div class="vr vr_x3">
        <div style="height:50px;background:#333333;"></div>
    </div>
    I have 10x of margin above me!
</div>

```markup
<div class="vr vr_x3">
    <div style="height:50px;background:#333333;"></div>
</div>
I have 15px of margin above me!
```

### 20px

<div class="sg-example">
    <div class="vr vr_x4">
        <div style="height:50px;background:#333333;"></div>
    </div>
    I have 20px of margin above me!
</div>

```markup
<div class="vr vr_x4">
    <div style="height:50px;background:#333333;"></div>
</div>
I have 5px of margin above me!
```

### 25px

<div class="sg-example">
    <div class="vr vr_x5">
        <div style="height:50px;background:#333333;"></div>
    </div>
    I have 25px of margin above me!
</div>

```markup
<div class="vr vr_x5">
    <div style="height:50px;background:#333333;"></div>
</div>
I have 5px of margin above me!
```