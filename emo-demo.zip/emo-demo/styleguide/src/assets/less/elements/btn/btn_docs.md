Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore deserunt, quo eos rem nihil blanditiis voluptatum porro voluptates sequi. Qui totam deleniti, quo atque! Asperiores, quibusdam recusandae! Provident, ea, consequuntur.

<div class="sg-example">
    <button class="btn">primary button</button>
</div>

```markup
<button class="btn">primary button</button>
```

## Color Extensions

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, saepe!

<div class="sg-example">
    <button class="btn btn_secondary">secondary button</button>
</div>

```markup
<button class="btn btn_secondary">secondary button</button>
```

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo dicta dolores laboriosam quod, ipsa autem.

<div class="sg-example">
    <button class="btn btn_tertiary">tertiary button</button>
</div>

```markup
<button class="btn btn_tertiary">tertiary button</button>
```

## Size Extensions

Lorem ipsum dolor sit amet.

<div class="sg-example">
    <button class="btn btn_sm">small button</button>
</div>

```markup
<button class="btn btn_sm">small button</button>
```

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque sit, nobis.

<div class="sg-example">
    <button class="btn btn_lg">large button</button>
</div>

```markup
<button class="btn btn_lg">large button</button>
```

## Other Extensions

### Block Level Buttons

<div class="sg-example">
    <button class="btn btn_block">large button</button>
</div>

```markup
<button class="btn btn_block">large button</button>
```