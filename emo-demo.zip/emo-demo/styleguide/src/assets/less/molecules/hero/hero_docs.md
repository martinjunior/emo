Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque possimus illo voluptatem architecto animi odit beatae inventore itaque fuga voluptatibus. Animi facere recusandae adipisci similique consectetur distinctio, harum officiis ad corporis, quasi dolorem, ea iure quam libero beatae nostrum reprehenderit!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nisi, sit?

<div class="sg-example">
    <div class="hero">
        <div class="wrapper">
            <div class="media">
                <img src="http://placehold.it/200x200" alt="" class="media-figure">
                <div class="media-bd">
                    <div class="vr vr_x3">
                        <h1 class="hdg hdg_1">Lorem ipsum dolor sit amet, consectetur.</h1>
                    </div>
                    <p class="pa-txt pa-txt_loose">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere dolorum doloremque ut architecto error possimus, aliquid tempora, autem nulla. Aspernatur atque earum voluptatibus magni expedita quod deserunt molestiae, a voluptas ratione. Commodi minus, at nulla iure omnis ducimus est nobis magni veniam possimus nostrum velit, voluptate voluptatum consequuntur, itaque dicta!</p>
                </div>
            </div>
        </div>
    </div>
</div>

```markup
<div class="hero">
    <div class="wrapper">
        <div class="media">
            <img src="http://placehold.it/200x200" alt="" class="media-figure">
            <div class="media-bd">
                <div class="vr vr_x3">
                    <h1 class="hdg hdg_1">Lorem ipsum dolor sit amet, consectetur.</h1>
                </div>
                <p class="pa-txt pa-txt_loose">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere dolorum doloremque ut architecto error possimus, aliquid tempora, autem nulla. Aspernatur atque earum voluptatibus magni expedita quod deserunt molestiae, a voluptas ratione. Commodi minus, at nulla iure omnis ducimus est nobis magni veniam possimus nostrum velit, voluptate voluptatum consequuntur, itaque dicta!</p>
            </div>
        </div>
    </div>
</div>
```