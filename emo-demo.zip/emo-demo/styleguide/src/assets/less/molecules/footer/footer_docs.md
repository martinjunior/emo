---
name: footer
category: molecules
---

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo!

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi temporibus obcaecati sit minus aut nisi consequatur repellat aperiam perspiciatis. Incidunt aliquid officia dolore laudantium animi.

<div class="sg-example">
    {% include 'partials/landmarks/_footer.html' %}
</div>

```markup
{% include 'partials/landmarks/_footer.html' %}
```