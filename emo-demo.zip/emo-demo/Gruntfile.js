module.exports = function(grunt) {

    grunt.initConfig({

        emo: {
            app: {
                options: {
                    components: ['styleguide/src/assets/scss/**/*.scss'],
                    views: 'views',
                    data: 'docs.json'
                },
                files: [
                    {
                        expand: true,
                        cwd: 'styleguide/src/',
                        src: [
                            'assets/styles/*.css'
                        ],
                        dest: 'styleguide/dest/'
                    }
                ]
            }
        },

        sass: {
            app: {
                options: {
                    outputStyle: 'compressed'
                },
                files: {
                    'styleguide/dest/assets/styles/app.css': 'styleguide/src/assets/scss/app.scss'
                }
            }
        },

        uglify: {
            app: {
                files: {
                    'styleguide/dest/assets/scripts/app.js': ['styleguide/src/assets/scripts/**/*.js']
                }
            }
        },

        watch: {
            app: {
                files: [
                    'src/**',
                    'styleguide/src/**'
                ],
                tasks: ['default'],
            }
        }

    });

    grunt.loadNpmTasks('grunt-emo');
    grunt.loadNpmTasks('grunt-sass');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-watch');

    grunt.registerTask('default', [
        'sass',
        'uglify',
        'emo'
    ]);

};